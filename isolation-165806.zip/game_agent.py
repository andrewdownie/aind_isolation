"""Finish all TODO items in this file to complete the isolation project, then
test your agent's strength against a set of known agents using tournament.py
and include the results in your report.
"""
import random
import math


class SearchTimeout(Exception):
    """Subclass base exception for code clarity. """
    pass

    
def custom_score(game, player):
    """Calculate the heuristic value of a game state from the point of view
    of the given player.

    Note: this function should be called from within a Player instance as
    `self.score()` -- you should not need to call this function directly.

    Parameters
    ----------
    game : `isolation.Board`
        An instance of `isolation.Board` encoding the current state of the
        game (e.g., player locations and blocked cells).

    player : object
        A player instance in the current game (i.e., an object corresponding to
        one of the player objects `game.__player_1__` or `game.__player_2__`.)

    Returns
    -------

        The heuristic value of the current game state to the specified player.
    """


    # ---- chase the opponent

# Try to move as close as possible to where the other player last moved
    if(None == game.get_player_location(game.get_opponent(player))):
        return (3, 3)

    opp_y, opp_x = game.get_player_location(game.get_opponent(player))
        
    y, x = game.get_player_location(player)
    return float((opp_x - y)**2 + (opp_y - x)**2)


def custom_score_2(game, player):
    """Calculate the heuristic value of a game state from the point of view
    of the given player.

    This should be the best heuristic function for your project submission.

    Note: this function should be called from within a Player instance as
    `self.score()` -- you should not need to call this function directly.

    Parameters
    ----------
    game : `isolation.Board`
        An instance of `isolation.Board` encoding the current state of the
        game (e.g., player locations and blocked cells).

    player : object
        A player instance in the current game (i.e., an object corresponding to
        one of the player objects `game.__player_1__` or `game.__player_2__`.)

    Returns
    -------
    float
        The heuristic value of the current game state to the specified player.
    """
    own_moves = len(game.get_legal_moves(player))
    opp_moves = len(game.get_legal_moves(game.get_opponent(player)))


    # ---- bottom right ab improved

    # If we are equal or behind, make it a priority to not fall any further behind
    if(own_moves < opp_moves):
        return float(own_moves - opp_moves)
    # If we are ahead, do something unique (fill up the bottom right corner)
    y, x = game.get_player_location(player)
    return float(x + y)






def custom_score_3(game, player):
    """Calculate the heuristic value of a game state from the point of view
    of the given player.

    Note: this function should be called from within a Player instance as
    `self.score()` -- you should not need to call this function directly.

    Parameters
    ----------
    game : `isolation.Board`
        An instance of `isolation.Board` encoding the current state of the
        game (e.g., player locations and blocked cells).

    player : object
        A player instance in the current game (i.e., an object corresponding to
        one of the player objects `game.__player_1__` or `game.__player_2__`.)

    Returns
    -------
    float
        The heuristic value of the current game state to the specified player.
    """

    own_moves = len(game.get_legal_moves(player))
    opp_moves = len(game.get_legal_moves(game.get_opponent(player)))
    move_diff = float(own_moves - opp_moves)


    opp_y, opp_x = game.get_player_location(game.get_opponent(player))
    y, x = game.get_player_location(player)
    dx = abs(x - opp_x) ** 2
    dy = abs(y - opp_y) ** 2
    opp_dist = math.sqrt(dx + dy)


    return float(opp_dist + move_diff)


class IsolationPlayer:
    """Base class for minimax and alphabeta agents -- this class is never
    constructed or tested directly.

    ********************  DO NOT MODIFY THIS CLASS  ********************

    Parameters
    ----------
    search_depth : int (optional)
        A strictly positive integer (i.e., 1, 2, 3,...) for the number of
        layers in the game tree to explore for fixed-depth search. (i.e., a
        depth of one (1) would only explore the immediate sucessors of the
        current state.)

    score_fn : callable (optional)
        A function to use for heuristic evaluation of game states.

    timeout : flout (optional)
        Time remaining (in milliseconds) when search is aborted. Should be a
        positive value large enough to allow the function to return before the
        timer expires.
    """
    # TODO: setting seach_depth=25 fixes test case 9.... how is this value supposed to be passed in from the test case?
    def __init__(self, search_depth=3, score_fn=custom_score, timeout=20.):
        self.search_depth = search_depth
        self.score = score_fn
        self.time_left = None
        self.TIMER_THRESHOLD = timeout


class MinimaxPlayer(IsolationPlayer):
    """Game-playing agent that chooses a move using depth-limited minimax
    search. You must finish and test this player to make sure it properly uses
    minimax to return a good move before the search time limit expires.
    """

    def get_move(self, game, time_left):
        """Search for the best move from the available legal moves and return a
        result before the time limit expires.

        **************  YOU DO NOT NEED TO MODIFY THIS FUNCTION  *************

        For fixed-depth search, this function simply wraps the call to the
        minimax method, but this method provides a common interface for all
        Isolation agents, and you will replace it in the AlphaBetaPlayer with
        iterative deepening search.

        Parameters
        ----------
        game : `isolation.Board`
            An instance of `isolation.Board` encoding the current state of the
            game (e.g., player locations and blocked cells).

        time_left : callable
            A function that returns the number of milliseconds left in the
            current turn. Returning with any less than 0 ms remaining forfeits
            the game.

        Returns
        -------
        (int, int)
            Board coordinates corresponding to a legal move; may return
            (-1, -1) if there are no available legal moves.
        """
        self.time_left = time_left
        #print("Player: " + str(game.active_player))

        # Initialize the best move so that this function returns something
        # in case the search fails due to timeout
        best_move = (-1, -1)

        try:
            # The try/except block will automatically catch the exception
            # raised when the timer is about to expire.
            best_move = self.minimax(game, self.search_depth)

        except SearchTimeout:
            print("timed out")
            # TODO: is this where it gets to before printing???
            pass  # Handle any actions required after timeout as needed

        # Return the best move from the last completed search iteration
        #print(best_move) #TODO: because it's never getting here
        return best_move

    def max_value(self, game, depth):
        if self.time_left() < self.TIMER_THRESHOLD:
            raise SearchTimeout()

        """active_player = game.active_player
        game_over = game.is_winner(active_player)
        game_over = game_over or game.is_loser(active_player)
        game_over = game_over or (len(game.get_legal_moves()) == 0) # TODO: is this correct?

        depth_reached = game.move_count >= depth

        if(game_over):
            print("game over - max_value")
            # return game.utility(active_player) # am I supposed to use self.score here?
            return self.score(game, active_player)

        if(depth_reached):
            print("depth reached - max_value")
            return self.score(game, active_player)""" # TODO: delete this

        utility = float("-inf")

        legal_moves = game.get_legal_moves()

        if not legal_moves or depth==0:
            return self.score(game, self)

        for move in legal_moves:
            forecast = game.forecast_move(move)
            utility = max(utility, self.min_value(forecast, depth - 1))
        
        return utility

    def min_value(self, game, depth):
        if self.time_left() < self.TIMER_THRESHOLD:
            raise SearchTimeout()

        """active_player = game.active_player
        game_over = game.is_winner(active_player)
        game_over = game_over or game.is_loser(active_player)
        game_over = game_over or (len(game.get_legal_moves()) == 0) # TODO: is this correct?
        depth_reached = game.move_count >= depth
        if(game_over):
            #print("game over - min_value")
            # return game.utility(active_player) # am I supposed to use self.score here? I don't think game.utility works without fully expanding the tree... which is not practical, we need to use a heuristic
            return self.score(game, active_player)
        if(depth_reached):
            #print("depth reached(" + str(depth) + ") - min_value")
            scr = self.score(game, active_player)
            #print("Depth reached for min_value, returning score: " + str(scr))
            return scr """ # TODO: delete this

        utility = float("inf")

        legal_moves = game.get_legal_moves()

        if not legal_moves or depth==0:
            return self.score(game, self)

        for move in legal_moves:
            forecast = game.forecast_move(move)
            utility = min(utility, self.max_value(forecast, depth - 1))
        
        #print("utility is: " + utility)
        return utility

    def minimax(self, game, depth):
        """Implement depth-limited minimax search algorithm as described in
        the lectures.

        This should be a modified version of MINIMAX-DECISION in the AIMA text.
        https://github.com/aimacode/aima-pseudocode/blob/master/md/Minimax-Decision.md

        **********************************************************************
            You MAY add additional methods to this class, or define helper
                 functions to implement the required functionality.
        **********************************************************************

        Parameters
        ----------
        game : isolation.Board
            An instance of the Isolation game `Board` class representing the
            current game state

        depth : int
            Depth is an integer representing the maximum number of plies to
            search in the game tree before aborting

        Returns
        -------
        (int, int)
            The board coordinates of the best move found in the current search;
            (-1, -1) if there are no legal moves

        Notes
        -----
            (1) You MUST use the `self.score()` method for board evaluation
                to pass the project tests; you cannot call any other evaluation
                function directly.

            (2) If you use any helper functions (e.g., as shown in the AIMA
                pseudocode) then you must copy the timer check into the top of
                each helper function or else your agent will timeout during
                testing.
        """

        if self.time_left() < self.TIMER_THRESHOLD:
            raise SearchTimeout()

        #active_player = game.active_player # TODO: delete this line

        best_move = (-1, -1)

        utility = float("-inf")
        legal_moves = game.get_legal_moves()

        if(len(legal_moves) > 0):
            best_move = legal_moves[0]

        for move in legal_moves:
            forecast = game.forecast_move(move)
            new_utility = self.min_value(forecast, depth - 1)
            if(new_utility > utility):
                utility = new_utility
                best_move = move

        #print("Best move is: " + str(best_move))
        return best_move


class AlphaBetaPlayer(IsolationPlayer):
    """Game-playing agent that chooses a move using iterative deepening minimax
    search with alpha-beta pruning. You must finish and test this player to
    make sure it returns a good move before the search time limit expires.
    """

    def get_move(self, game, time_left):
        """Search for the best move from the available legal moves and return a
        result before the time limit expires.

        Modify the get_move() method from the MinimaxPlayer class to implement
        iterative deepening search instead of fixed-depth search.

        **********************************************************************
        NOTE: If time_left() < 0 when this function returns, the agent will
              forfeit the game due to timeout. You must return _before_ the
              timer reaches 0.
        **********************************************************************

        Parameters
        ----------
        game : `isolation.Board`
            An instance of `isolation.Board` encoding the current state of the
            game (e.g., player locations and blocked cells).

        time_left : callable
            A function that returns the number of milliseconds left in the
            current turn. Returning with any less than 0 ms remaining forfeits
            the game.

        Returns
        -------
        (int, int)
            Board coordinates corresponding to a legal move; may return
            (-1, -1) if there are no available legal moves.
        """
        #TODO: old
        """
        if not game.get_legal_moves()[0]:
            try:
                depth=1
                while True:
                    best_move = self.alphabeta(game, depth)
                    depth+=1
            except SearchTimeout:
                print("except: timed out")
        """

        #TODO: new
        self.time_left = time_left
        if not game.get_legal_moves():
            return (-1, -1)
        best_move = game.get_legal_moves()[0]
        try:
            depth=1
            while True:
                best_move = self.alphabeta(game, depth)
                depth+=1
        except SearchTimeout:
            pass
        return best_move


    def alphabeta(self, game, depth, alpha=float("-inf"), beta=float("inf")):
        """Implement depth-limited minimax search with alpha-beta pruning as
        described in the lectures.

        This should be a modified version of ALPHA-BETA-SEARCH in the AIMA text
        https://github.com/aimacode/aima-pseudocode/blob/master/md/Alpha-Beta-Search.md

        **********************************************************************
            You MAY add additional methods to this class, or define helper
                 functions to implement the required functionality.
        **********************************************************************

        Parameters
        ----------
        game : isolation.Board
            An instance of the Isolation game `Board` class representing the
            current game state

        depth : int
            Depth is an integer representing the maximum number of plies to
            search in the game tree before aborting

        alpha : float
            Alpha limits the lower bound of search on minimizing layers

        beta : float
            Beta limits the upper bound of search on maximizing layers

        Returns
        -------
        (int, int)
            The board coordinates of the best move found in the current search;
            (-1, -1) if there are no legal moves

        Notes
        -----
            (1) You MUST use the `self.score()` method for board evaluation
                to pass the project tests; you cannot call any other evaluation
                function directly.

            (2) If you use any helper functions (e.g., as shown in the AIMA
                pseudocode) then you must copy the timer check into the top of
                each helper function or else your agent will timeout during
                testing.
        """
        if self.time_left() < self.TIMER_THRESHOLD:
            raise SearchTimeout()

        if not game.get_legal_moves():
            return (-1, -1)
        legal_moves = game.get_legal_moves()
        best_move = legal_moves[0]
        utility = float("-inf")


        """
        if(len(legal_moves) > 0):
            best_move = legal_moves[0]
        """

        for move in legal_moves:

            forecast = game.forecast_move(move)
            new_utility = max(utility, self.min_value(forecast, alpha, beta, depth))
            if(new_utility > utility):
                utility = new_utility
                best_move = move
            alpha = max(alpha, utility)

        """
        if(best_move == (-1, -1) and len(legal_moves) > 0):
            #TODO: why is legal moves empty sometimes, but then has elements later on the same turn?
            print(legal_moves)
            print("uh oh spaghetti oh's")
        """
        
        return best_move


    def max_value(self, game, alpha, beta, depth):
        if self.time_left() < self.TIMER_THRESHOLD:
            raise SearchTimeout()

        utility = float("-inf")

        legal_moves = game.get_legal_moves()

        for move in legal_moves:
            forecast = game.forecast_move(move)
            utility = max(utility, self.min_value(forecast, alpha, beta, depth))

            if(utility >= beta):
                return utility

            alpha = max(alpha, utility)

        return utility

    def min_value(self, game, alpha, beta, depth):
        if self.time_left() < self.TIMER_THRESHOLD:
            raise SearchTimeout()

        utility = float("inf")

        legal_moves = game.get_legal_moves()

        for move in legal_moves:
            forecast = game.forecast_move(move)
            utility = min(utility, self.max_value(forecast, alpha, beta, depth))

            if(utility <= alpha):
                return utility

            beta = min(beta, utility)

        return utility